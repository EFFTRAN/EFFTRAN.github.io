PATH=.\g77\bin;%PATH%
SET LIBRARY_PATH=.\g77\lib
g77 -O3 -w -o buildup.exe buildup.f
g77 -O3 -w -o correct.exe correct.f
g77 -O3 -w -o efficiency.exe efficiency.f
g77 -O3 -w -o emissions.exe emissions.f
g77 -O3 -w -o emissions2.exe emissions2.f
g77 -O3 -w -o energy.exe energy.f
g77 -O3 -w -o eta.exe eta.f
g77 -O3 -w -o gv.exe gv.f
g77 -O3 -w -o initialize.exe initialize.f
g77 -O3 -w -o mine.exe mine.f
g77 -O3 -w -o peak.exe peak.f
g77 -O3 -w -o ptt.exe ptt.f
g77 -O3 -w -o scatter.exe scatter.f
g77 -O3 -w -o total.exe total.f
g77 -O3 -w -o transfer.exe transfer.f
g77 -O3 -w -o .\xcom\xcom.exe .\xcom\xcom.for
