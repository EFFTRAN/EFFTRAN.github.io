rem parameter: nuclide name
rem input: buildup.txt, efficiency.txt
rem output: correct.txt
del /Q /F correct.txt
del /Q /F peak.txt
del /Q /F emissions.txt
del /Q /F emissions2.txt
initialize.exe
if not exist .\Decay_Data\%1.txt goto end
copy .\Decay_Data\%1.txt coin.txt
emissions.exe
emissions2.exe
peak.exe
if not exist .\Decay_Data\%1b.txt goto end
copy .\Decay_Data\%1b.txt coin.txt
emissions.exe
emissions2.exe
peak.exe
:end
correct.exe
