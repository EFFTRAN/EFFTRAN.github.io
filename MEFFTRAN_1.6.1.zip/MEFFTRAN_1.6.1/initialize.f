
	program initialize

	implicit none

	double precision s(3000)
	integer i

	do i=1,3000
          s(i)=0.
        enddo

        open(7,file='peak.txt',status='unknown')
        do i=1,3000
          write(7,77) i,s(i)
        enddo
	close(7)

        open(7,file='emissions.txt',status='unknown')
        do i=1,3000
          write(7,77) i,s(i)
        enddo
	close(7)

        open(7,file='emissions2.txt',status='unknown')
        do i=1,3000
          write(7,77) i,s(i)
        enddo
	close(7)

77	format(i10,e15.5)

	end
