CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
C                                                                       C
C  EFFTRAN (version 4.8 2026)                                           C
C  Copyright (c) 2005-2026                                              C
C  Tim Vidmar                                                           C
C                                                                       C
C  Permission to use, copy, modify, distribute and sell this software   C
C  and its documentation for any purpose is hereby granted without      C
C  fee, provided that the above copyright notice appears in all         C
C  copies and that both that copyright notice and this permission       C
C  notice appear in all supporting documentation. Tim Vidmar makes      C
C  no representations about the suitability of this software for any    C
C  purpose. It is provided 'as is' without express or implied warranty. C
C                                                                       C
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC

-- Coincidence summing corrections calculated in one go for all the 
   nuclides in the library

EFFTRAN website is located at https://efftran.github.io/.

Whenever you are installing a new version of EFFTRAN, install it cleanly into a 
new directory and not over an existing version. Then redefine all the materials 
and all the detector and source models. We apologise for this inconvenience, but
there is no other way of guaranteeing that the new version will work correctly.

July 2026

