@echo off
rem input: detector.txt, sample.txt
rem output: buildup.txt, efficiency.txt
del /Q /F total.txt
del /Q /F scatter.txt
del /Q /F buildup.txt
del /Q /F eta.txt
del /Q /F ptt.txt
del /Q /F efficiency.txt
del /Q /F mine.txt
del /Q /F reference.txt
copy sample.txt source.txt
mine.exe
energy.exe
total.exe
scatter.exe
buildup.exe
eta.exe
ptt.exe
efficiency.exe

