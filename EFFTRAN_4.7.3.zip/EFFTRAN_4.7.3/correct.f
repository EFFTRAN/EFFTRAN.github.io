
        program corrections

        implicit none

        real x(3000),x1(3000),x2(3000)
        integer i,j

        open(7,file='emissions.txt',status='old')
        do i=1,3000
          read(7,*) j,x(i)
        enddo
        close(7)

        open(7,file='peak.txt',status='old')
        do i=1,3000
          read(7,*) j,x1(i)
        enddo
        close(7)

        open(7,file='emissions2.txt',status='old')
        do i=1,3000
          read(7,*) j,x2(i)
        enddo
        close(7)

        open(7,file='correct.txt',status='unknown')
        do i=2,3000
          if (x(i).gt.0..and.x1(i).gt.0..and.x2(i).gt.0.)
     +    write(7,77) i,x(i)/(x1(i)-x2(i)+x(i))
        enddo
        close(7)
77      format(i10,e15.5)

        end
