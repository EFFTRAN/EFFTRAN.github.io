@echo off
rem input: detector.txt, sample.txt, standard.txt, reference.txt
rem output: efficiency.txt
del /Q /F  standard-efficiency.txt
del /Q /F sample-efficiency.txt
del /Q /F efficiency.txt
del /Q /F total.txt
copy sample.txt source.txt
total.exe
copy total.txt sample-efficiency.txt
copy standard.txt source.txt
del /Q /F total.txt
total.exe
copy total.txt standard-efficiency.txt
transfer.exe
