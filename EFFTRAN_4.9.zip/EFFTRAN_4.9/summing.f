
      program summing

      implicit none

      real pd(20),uncd(20),ps(10),uncs(10)
      real rho,urho

      integer e(10000)
      real u(10000),t(10000),s(10000),x
      character*10 nuc(10000)
      
      character*70 dmat,wmat,cmat,hmat,amat
      character*70 smat,bmat

      integer npd,nps,n0,n,nn,idum
      integer i,j,l,r

      real ran1
      external ran1

      npd=14
      nps=5

      call system('copy detector.txt det.txt')
      call system('copy source.txt src.txt')

      call system('mine.exe')
      call system('energy.exe')
      call system('total.exe')
      call system('scatter.exe')
      call system('buildup.exe')
      call system('eta.exe')
      call system('ptt.exe')
      call system('efficiency.exe')
      call system('coin.exe')

      end

      integer function left(s)
      implicit none
      integer n,l
      character blank
      character*(*) s
      blank=' '
      l=len(s)
      n=1
      do while (s(n:n).eq.blank.and.n.lt.l)
        n=n+1
      enddo
      left=n
      return
      end

      integer function right(s)
      implicit none
      integer n
      character blank
      character*(*) s
      blank=' '
      n=len(s)
      do while (s(n:n).eq.blank.and.n.gt.1)
        n=n-1
      enddo
      right=n
      return
      end

      FUNCTION ran1(idum)
      INTEGER idum,IA,IM,IQ,IR,NTAB,NDIV
      REAL ran1,AM,EPS,RNMX
      PARAMETER (IA=16807,IM=2147483647,AM=1./IM,IQ=127773,IR=2836,
     *NTAB=32,NDIV=1+(IM-1)/NTAB,EPS=1.2e-7,RNMX=1.-EPS)
      INTEGER j,k,iv(NTAB),iy
      SAVE iv,iy
      DATA iv /NTAB*0/, iy /0/
      if (idum.le.0.or.iy.eq.0) then
        idum=max(-idum,1)
        do 11 j=NTAB+8,1,-1
          k=idum/IQ
          idum=IA*(idum-k*IQ)-IR*k
          if (idum.lt.0) idum=idum+IM
          if (j.le.NTAB) iv(j)=idum
11      continue
        iy=iv(1)
      endif
      k=idum/IQ
      idum=IA*(idum-k*IQ)-IR*k
      if (idum.lt.0) idum=idum+IM
      j=1+iy/NDIV
      iy=iv(j)
      iv(j)=idum
      ran1=min(AM*iy,RNMX)
      return
      END
C  (C) Copr. 1986-92 Numerical Recipes Software ,)+>.
