
      program transfer

      implicit none

      real e(1000),eps(1000),unc(1000)
      real pd(20),uncd(20),ps(10),uncs(10),px(10),uncx(10)
      real rhos,rhox,urhos,urhox

      real u(100),us(100),ux(100)
      real t(100),s(100),x
      real sigs(100),sigx(100),sig(100)
      real dummy

      character*70 dmat,wmat,cmat,hmat,amat
      character*70 smats,bmats,smatx,bmatx

      integer ne,npd,nps,n,n0,idum
      integer i,j,l,r

      real ran1
      external ran1

      ne=1
      open(7,file='reference.txt',status='old')
11    continue
      read(7,*,end=22) e(ne),eps(ne),unc(ne)
      unc(ne)=unc(ne)/100.
      ne=ne+1
      goto 11
22    continue
      close(7)
      ne=ne-1
      close(7)

      call system('copy detector.txt det.txt')
      call system('copy standard.txt src.txt')

      call system('total.exe')
      open(7,file='total.txt',status='old')
      do j=1,ne
        read(7,*) x,us(j),dummy,sigs(j)
      enddo
      close(7)

      call system('copy sample.txt src.txt')

      call system('total.exe')
      open(7,file='total.txt',status='old')
      do j=1,ne
        read(7,*) x,ux(j),dummy,sigx(j)
      enddo
      close(7)

      do j=1,ne
        t(j)=ux(j)/us(j)
        eps(j)=eps(j)*t(j)
        sig(j)=unc(j)*unc(j)+sigs(j)*sigs(j)+sigx(j)*sigx(j)
	sig(j)=sqrt(sig(j))
      enddo
   
      open(7,file='efficiency.txt',status='unknown')
      do j=1,ne
        write(7,99) e(j),eps(j),100.*sig(j)
      enddo
      close(7)
99    format(f12.1,e15.5,f12.1)

      end

      integer function left(s)
      implicit none
      integer n,l
      character blank
      character*(*) s
      blank=' '
      l=len(s)
      n=1
      do while (s(n:n).eq.blank.and.n.lt.l)
        n=n+1
      enddo
      left=n
      return
      end

      integer function right(s)
      implicit none
      integer n
      character blank
      character*(*) s
      blank=' '
      n=len(s)
      do while (s(n:n).eq.blank.and.n.gt.1)
        n=n-1
      enddo
      right=n
      return
      end

      FUNCTION ran1(idum)
      INTEGER idum,IA,IM,IQ,IR,NTAB,NDIV
      REAL ran1,AM,EPS,RNMX
      PARAMETER (IA=16807,IM=2147483647,AM=1./IM,IQ=127773,IR=2836,
     *NTAB=32,NDIV=1+(IM-1)/NTAB,EPS=1.2e-7,RNMX=1.-EPS)
      INTEGER j,k,iv(NTAB),iy
      SAVE iv,iy
      DATA iv /NTAB*0/, iy /0/
      if (idum.le.0.or.iy.eq.0) then
        idum=max(-idum,1)
        do 11 j=NTAB+8,1,-1
          k=idum/IQ
          idum=IA*(idum-k*IQ)-IR*k
          if (idum.lt.0) idum=idum+IM
          if (j.le.NTAB) iv(j)=idum
11      continue
        iy=iv(1)
      endif
      k=idum/IQ
      idum=IA*(idum-k*IQ)-IR*k
      if (idum.lt.0) idum=idum+IM
      j=1+iy/NDIV
      iy=iv(j)
      iv(j)=idum
      ran1=min(AM*iy,RNMX)
      return
      END
C  (C) Copr. 1986-92 Numerical Recipes Software ,)+>.
